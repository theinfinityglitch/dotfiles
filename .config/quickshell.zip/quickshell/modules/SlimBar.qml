import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Hyprland
import Quickshell.Services.Mpris

PanelWindow {
    id: root

    implicitHeight: 5
    color: Colors.background

    anchors {
        top: true
        left: true
        right: true
    }

    Workspaces {
        anchors.centerIn: parent
    }

    Rectangle {
        id: mediaIndicator

        property var players: Mpris.players.values
        property var player: Mpris.players.length > 0 ? Mpris.players[0] : null
        property bool isPlaying: player ? (player.playbackStatus === "Playing") : false

        visible: players.lenght > 0
        color: isPlaying ? Colors.green : Colors.red
        implicitHeight: parent.height
        implicitWidth: 200
        anchors.leftMargin: 2

        anchors {
            left: parent.left
            verticalCenter: parent.verticalCenter
        }

    }

}
