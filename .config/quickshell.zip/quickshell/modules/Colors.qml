import QtQuick
import Quickshell
pragma Singleton

Singleton {
    id: root

    readonly property color background: "#282828"
    readonly property color backgroundLight: "#3c3836"
    readonly property color foreground: "#ebdbb2"
    readonly property color black: "#32302f"
    readonly property color red: "#cc241d"
    readonly property color green: "#98971a"
    readonly property color yellow: "#d79921"
    readonly property color blue: "#458588"
    readonly property color magenta: "#b16286"
    readonly property color cyan: "#689d6a"
    readonly property color white: "#ebdbb2"
    readonly property color orange: "#d65d0e"
    // Module-specific colors
    readonly property color workspaceColor: foreground
    readonly property color workspaceFocussedColor: cyan
    readonly property color workspaceEmptyColor: backgroundLight
}
