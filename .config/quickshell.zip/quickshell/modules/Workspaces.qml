import QtQuick
import Quickshell
import Quickshell.Hyprland

Rectangle {
    id: root

    property var workspaceNumbers: {
        const nums = new Set([1, 2, 3, 4, 5]);
        Hyprland.workspaces.values.forEach((w) => {
            if (w.id > 0)
                nums.add(w.id);

        });
        return Array.from(nums).sort((a, b) => {
            return a - b;
        });
    }

    implicitWidth: row.implicitWidth
    implicitHeight: parent.height
    color: "transparent"

    Row {
        id: row

        anchors.centerIn: parent
        height: parent.height
        spacing: 4

        Repeater {
            model: root.workspaceNumbers

            delegate: Rectangle {
                id: segment

                required property int modelData
                readonly property bool isFocused: Hyprland.focusedWorkspace && Hyprland.focusedWorkspace.id === modelData
                readonly property var wsRef: Hyprland.workspaces.values.find((w) => {
                    return w.id === modelData;
                })

                width: 50
                height: parent.height
                color: isFocused ? Colors.workspaceFocussedColor : wsRef ? Colors.workspaceColor : Colors.workspaceEmptyColor

                MouseArea {
                    id: mouse

                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: Hyprland.dispatch("hl.dsp.focus({ workspace = " + segment.modelData + " })")
                }

                PopupWindow {
                    id: tooltip

                    visible: mouse.containsMouse
                    anchor.item: segment
                    anchor.edges: Edges.Bottom
                    anchor.gravity: Edges.Bottom
                    anchor.margins.top: 6
                    implicitWidth: labelText.implicitWidth + 12
                    implicitHeight: labelText.implicitHeight + 6
                    color: Colors.background

                    Text {
                        id: labelText

                        anchors.centerIn: parent
                        text: "Workspace " + segment.modelData
                        color: Colors.foreground
                        font.pixelSize: 11
                    }

                }

            }

        }

    }

}
